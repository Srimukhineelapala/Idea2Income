import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Bookmark, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { BusinessIdea } from "@/lib/types";
import { getSavedIdeas, removeIdea } from "@/lib/saved-ideas";
import { IdeaCard } from "@/components/IdeaCard";
import { Button } from "@/components/ui/button";

export default function SavedPage() {
  const navigate = useNavigate();
  const [ideas, setIdeas] = useState<BusinessIdea[]>([]);

  useEffect(() => {
    setIdeas(getSavedIdeas());
  }, []);

  const handleRemove = (idea: BusinessIdea) => {
    removeIdea(idea.id);
    setIdeas((prev) => prev.filter((i) => i.id !== idea.id));
  };

  return (
    <div className="min-h-screen pb-24">
      <div className="px-5 pt-8 max-w-md mx-auto">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-2 mb-1">
            <Bookmark size={20} className="text-primary" />
            <h1 className="text-xl font-display font-bold text-foreground">Saved Ideas</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-6">{ideas.length} ideas saved</p>
        </motion.div>

        {ideas.length === 0 ? (
          <div className="text-center py-16">
            <Bookmark size={48} className="mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground mb-4">No saved ideas yet. Explore and save ideas you like!</p>
            <Button variant="hero" onClick={() => navigate("/explore")}>
              Explore Ideas
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {ideas.map((idea, i) => (
              <div key={idea.id} className="relative">
                <IdeaCard
                  idea={idea}
                  index={i}
                  onSelect={(idea) => navigate(`/idea/${idea.id}`, { state: idea })}
                  onSave={handleRemove}
                  isSaved={true}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
