import { motion } from "framer-motion";
import { Lightbulb, ArrowRight, TrendingUp, IndianRupee, Target } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  const navigate = useNavigate();

  const features = [
    { icon: Lightbulb, title: "AI-Powered Ideas", desc: "Get smart business suggestions based on your budget and skills" },
    { icon: IndianRupee, title: "Profit Analysis", desc: "Detailed investment, income, and break-even calculations" },
    { icon: Target, title: "Location-Based", desc: "Ideas tailored for Indian cities and local demand" },
    { icon: TrendingUp, title: "Compare & Save", desc: "Compare ideas side-by-side and save your favorites" },
  ];

  return (
    <div className="min-h-screen pb-20">
      {/* Hero */}
      <div className="gradient-hero px-6 pt-12 pb-10 rounded-b-[2rem]">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-md mx-auto text-center"
        >
          <div className="inline-flex items-center gap-2 bg-primary-foreground/20 rounded-full px-4 py-1.5 mb-4">
            <Lightbulb size={16} className="text-primary-foreground" />
            <span className="text-xs font-medium text-primary-foreground">Smart Business Planner</span>
          </div>
          <h1 className="text-3xl font-display font-bold text-primary-foreground mb-3">
            Idea2Income
          </h1>
          <p className="text-primary-foreground/80 text-sm mb-6 leading-relaxed">
            Turn your budget into a profitable business. Get AI-powered ideas with real profit analysis for Indian entrepreneurs.
          </p>
          <Button
            variant="hero"
            size="lg"
            className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 shadow-elevated"
            onClick={() => navigate("/explore")}
          >
            Start Exploring
            <ArrowRight size={18} />
          </Button>
        </motion.div>
      </div>

      {/* Features */}
      <div className="px-5 -mt-6 max-w-md mx-auto">
        <div className="grid grid-cols-2 gap-3">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.1 }}
              className="bg-card border border-border rounded-lg p-4 shadow-card"
            >
              <div className="w-9 h-9 rounded-lg gradient-primary flex items-center justify-center mb-3">
                <f.icon size={18} className="text-primary-foreground" />
              </div>
              <h3 className="font-display font-semibold text-sm text-card-foreground mb-1">{f.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="px-5 mt-6 max-w-md mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="bg-card border border-border rounded-lg p-5 shadow-card"
        >
          <h2 className="font-display font-semibold text-foreground mb-3">Why Idea2Income?</h2>
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <p className="text-2xl font-display font-bold text-primary">20+</p>
              <p className="text-xs text-muted-foreground">Business Ideas</p>
            </div>
            <div>
              <p className="text-2xl font-display font-bold text-success">₹10K</p>
              <p className="text-xs text-muted-foreground">Min Budget</p>
            </div>
            <div>
              <p className="text-2xl font-display font-bold text-secondary">4</p>
              <p className="text-xs text-muted-foreground">Categories</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
