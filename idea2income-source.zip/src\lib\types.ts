export type Category = "food" | "online" | "retail" | "services";
export type SkillLevel = "beginner" | "intermediate" | "expert";
export type RiskLevel = "Low" | "Medium" | "High";

export interface BusinessInput {
  budget: number;
  category: Category;
  skillLevel: SkillLevel;
  location: string;
}

export interface BusinessIdea {
  id: string;
  name: string;
  description: string;
  category: Category;
  requiredSkills: string[];
  targetAudience: string;
  investment: {
    equipment: number;
    setup: number;
    miscellaneous: number;
    total: number;
  };
  monthlyExpense: {
    rent: number;
    rawMaterials: number;
    salaries: number;
    total: number;
  };
  dailyIncome: number;
  monthlyIncome: number;
  profit: number;
  profitPercentage: number;
  breakEvenMonths: number;
  riskLevel: RiskLevel;
  growthPotential: number; // 1-10
  locationRelevance: string;
}
