import { Utensils, Globe, ShoppingBag, Wrench } from "lucide-react";
import { Category } from "@/lib/types";

const icons: Record<Category, React.ElementType> = {
  food: Utensils,
  online: Globe,
  retail: ShoppingBag,
  services: Wrench,
};

const colors: Record<Category, string> = {
  food: "text-primary",
  online: "text-secondary",
  retail: "text-accent",
  services: "text-warning",
};

export function CategoryIcon({ category, size = 20 }: { category: Category; size?: number }) {
  const Icon = icons[category];
  return <Icon size={size} className={colors[category]} />;
}
