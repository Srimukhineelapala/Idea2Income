import { motion } from "framer-motion";
import { ArrowLeft, Bookmark, BookmarkCheck, TrendingUp, Clock, Shield, Users, Zap } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { BusinessIdea } from "@/lib/types";
import { saveIdea, removeIdea, isIdeaSaved } from "@/lib/saved-ideas";
import { CategoryIcon } from "@/components/CategoryIcon";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from "recharts";

const CHART_COLORS = ["hsl(152, 55%, 38%)", "hsl(168, 40%, 48%)", "hsl(80, 50%, 45%)", "hsl(45, 93%, 47%)"];

export default function IdeaDetailPage() {
  const loc = useLocation();
  const navigate = useNavigate();
  const idea = loc.state as BusinessIdea | null;
  const [saved, setSaved] = useState(idea ? isIdeaSaved(idea.id) : false);

  if (!idea) {
    navigate("/");
    return null;
  }

  const toggleSave = () => {
    if (saved) {
      removeIdea(idea.id);
    } else {
      saveIdea(idea);
    }
    setSaved(!saved);
  };

  const investmentData = [
    { name: "Equipment", value: idea.investment.equipment },
    { name: "Setup", value: idea.investment.setup },
    { name: "Misc", value: idea.investment.miscellaneous },
  ].filter((d) => d.value > 0);

  const incomeData = [
    { name: "Income", value: idea.monthlyIncome },
    { name: "Expenses", value: idea.monthlyExpense.total },
    { name: "Profit", value: idea.profit },
  ];

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <div className="gradient-hero px-5 pt-6 pb-8 rounded-b-[2rem]">
        <div className="max-w-md mx-auto">
          <div className="flex items-center justify-between mb-4">
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary-foreground/10" onClick={() => navigate(-1)}>
              <ArrowLeft size={20} />
            </Button>
            <Button variant="ghost" size="icon" className="text-primary-foreground hover:bg-primary-foreground/10" onClick={toggleSave}>
              {saved ? <BookmarkCheck size={20} /> : <Bookmark size={20} />}
            </Button>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <CategoryIcon category={idea.category} size={24} />
            <Badge variant="outline" className="border-primary-foreground/30 text-primary-foreground text-xs">{idea.category}</Badge>
          </div>
          <h1 className="text-2xl font-display font-bold text-primary-foreground mb-2">{idea.name}</h1>
          <p className="text-sm text-primary-foreground/80 leading-relaxed">{idea.description}</p>
        </div>
      </div>

      <div className="px-5 -mt-4 max-w-md mx-auto space-y-4">
        {/* Key Metrics */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-2 gap-3">
          {[
            { label: "Investment", value: `₹${idea.investment.total.toLocaleString("en-IN")}`, icon: Zap, color: "text-primary" },
            { label: "Monthly Profit", value: `₹${idea.profit.toLocaleString("en-IN")}`, icon: TrendingUp, color: "text-success" },
            { label: "Break Even", value: `${idea.breakEvenMonths} month${idea.breakEvenMonths > 1 ? "s" : ""}`, icon: Clock, color: "text-secondary" },
            { label: "Risk Level", value: idea.riskLevel, icon: Shield, color: idea.riskLevel === "Low" ? "text-success" : "text-warning" },
          ].map((m) => (
            <div key={m.label} className="bg-card border border-border rounded-lg p-4 shadow-card">
              <div className="flex items-center gap-1.5 mb-1">
                <m.icon size={14} className={m.color} />
                <span className="text-xs text-muted-foreground">{m.label}</span>
              </div>
              <p className={`font-display font-bold ${m.color}`}>{m.value}</p>
            </div>
          ))}
        </motion.div>

        {/* Investment Breakdown */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-card border border-border rounded-lg p-5 shadow-card">
          <h2 className="font-display font-semibold text-foreground mb-3">Investment Breakdown</h2>
          <div className="flex items-center">
            <div className="w-28 h-28">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={investmentData} cx="50%" cy="50%" innerRadius={30} outerRadius={50} dataKey="value" strokeWidth={2}>
                    {investmentData.map((_, i) => (
                      <Cell key={i} fill={CHART_COLORS[i]} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-2 ml-4">
              {investmentData.map((d, i) => (
                <div key={d.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: CHART_COLORS[i] }} />
                    <span className="text-sm text-muted-foreground">{d.name}</span>
                  </div>
                  <span className="text-sm font-medium text-foreground">₹{d.value.toLocaleString("en-IN")}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Monthly Overview Chart */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-card border border-border rounded-lg p-5 shadow-card">
          <h2 className="font-display font-semibold text-foreground mb-3">Monthly Overview</h2>
          <div className="h-40">
            <ResponsiveContainer>
              <BarChart data={incomeData}>
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`} />
                <Tooltip formatter={(v: number) => `₹${v.toLocaleString("en-IN")}`} />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {incomeData.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Monthly Expenses */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="bg-card border border-border rounded-lg p-5 shadow-card">
          <h2 className="font-display font-semibold text-foreground mb-3">Monthly Expenses</h2>
          <div className="space-y-3">
            {[
              { label: "Rent", value: idea.monthlyExpense.rent },
              { label: "Raw Materials", value: idea.monthlyExpense.rawMaterials },
              { label: "Salaries", value: idea.monthlyExpense.salaries },
            ].filter(e => e.value > 0).map((e) => (
              <div key={e.label} className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">{e.label}</span>
                <span className="text-sm font-medium text-foreground">₹{e.value.toLocaleString("en-IN")}</span>
              </div>
            ))}
            <div className="border-t border-border pt-2 flex items-center justify-between">
              <span className="text-sm font-semibold text-foreground">Total</span>
              <span className="text-sm font-bold text-primary">₹{idea.monthlyExpense.total.toLocaleString("en-IN")}</span>
            </div>
          </div>
        </motion.div>

        {/* Skills & Audience */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="bg-card border border-border rounded-lg p-5 shadow-card">
          <h2 className="font-display font-semibold text-foreground mb-3">Required Skills</h2>
          <div className="flex flex-wrap gap-1.5 mb-4">
            {idea.requiredSkills.map((s) => (
              <Badge key={s} variant="secondary" className="text-xs">{s}</Badge>
            ))}
          </div>
          <h2 className="font-display font-semibold text-foreground mb-2 flex items-center gap-1.5">
            <Users size={16} /> Target Audience
          </h2>
          <p className="text-sm text-muted-foreground">{idea.targetAudience}</p>
        </motion.div>

        {/* Profit Summary */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="gradient-success rounded-lg p-5 shadow-card">
          <h2 className="font-display font-semibold text-success-foreground mb-3">Profit Summary</h2>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-xs text-success-foreground/70">Daily Income</p>
              <p className="font-display font-bold text-success-foreground">₹{idea.dailyIncome.toLocaleString("en-IN")}</p>
            </div>
            <div>
              <p className="text-xs text-success-foreground/70">Monthly Income</p>
              <p className="font-display font-bold text-success-foreground">₹{idea.monthlyIncome.toLocaleString("en-IN")}</p>
            </div>
            <div>
              <p className="text-xs text-success-foreground/70">Net Profit</p>
              <p className="font-display font-bold text-success-foreground">₹{idea.profit.toLocaleString("en-IN")}</p>
            </div>
            <div>
              <p className="text-xs text-success-foreground/70">Profit Margin</p>
              <p className="font-display font-bold text-success-foreground">{idea.profitPercentage}%</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
