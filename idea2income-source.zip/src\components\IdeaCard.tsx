import { motion } from "framer-motion";
import { TrendingUp, Shield, Bookmark, BookmarkCheck } from "lucide-react";
import { BusinessIdea } from "@/lib/types";
import { CategoryIcon } from "./CategoryIcon";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const riskColors: Record<string, string> = {
  Low: "bg-success/10 text-success border-success/20",
  Medium: "bg-warning/10 text-warning border-warning/20",
  High: "bg-destructive/10 text-destructive border-destructive/20",
};

interface IdeaCardProps {
  idea: BusinessIdea;
  index: number;
  onSelect: (idea: BusinessIdea) => void;
  onSave?: (idea: BusinessIdea) => void;
  isSaved?: boolean;
}

export function IdeaCard({ idea, index, onSelect, onSave, isSaved }: IdeaCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.4 }}
      className="group cursor-pointer rounded-lg border border-border bg-card p-5 shadow-card transition-all hover:shadow-elevated hover:-translate-y-1"
      onClick={() => onSelect(idea)}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <CategoryIcon category={idea.category} />
          <h3 className="font-display font-semibold text-card-foreground">{idea.name}</h3>
        </div>
        {onSave && (
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={(e) => {
              e.stopPropagation();
              onSave(idea);
            }}
          >
            {isSaved ? <BookmarkCheck size={18} className="text-primary" /> : <Bookmark size={18} />}
          </Button>
        )}
      </div>

      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{idea.description}</p>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="rounded-md bg-muted/50 p-2.5 text-center">
          <p className="text-xs text-muted-foreground">Investment</p>
          <p className="font-display font-bold text-foreground">₹{idea.investment.total.toLocaleString("en-IN")}</p>
        </div>
        <div className="rounded-md bg-success/5 p-2.5 text-center">
          <p className="text-xs text-muted-foreground">Monthly Profit</p>
          <p className="font-display font-bold text-success">₹{idea.profit.toLocaleString("en-IN")}</p>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <Badge variant="outline" className={riskColors[idea.riskLevel]}>
          <Shield size={12} className="mr-1" />
          {idea.riskLevel} Risk
        </Badge>
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <TrendingUp size={14} className="text-success" />
          <span>{idea.profitPercentage}% margin</span>
        </div>
      </div>
    </motion.div>
  );
}
