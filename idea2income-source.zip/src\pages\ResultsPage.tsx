import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, SlidersHorizontal } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";
import { BusinessIdea, BusinessInput } from "@/lib/types";
import { generateIdeas } from "@/lib/mock-data";
import { saveIdea, removeIdea, isIdeaSaved } from "@/lib/saved-ideas";
import { IdeaCard } from "@/components/IdeaCard";
import { Button } from "@/components/ui/button";

export default function ResultsPage() {
  const loc = useLocation();
  const navigate = useNavigate();
  const input = loc.state as BusinessInput | null;
  const [ideas, setIdeas] = useState<BusinessIdea[]>([]);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!input) {
      navigate("/explore");
      return;
    }
    const timer = setTimeout(() => {
      setIdeas(generateIdeas(input));
      setLoading(false);
    }, 1200);
    return () => clearTimeout(timer);
  }, [input, navigate]);

  useEffect(() => {
    setSavedIds(new Set(ideas.filter((i) => isIdeaSaved(i.id)).map((i) => i.id)));
  }, [ideas]);

  const handleSave = (idea: BusinessIdea) => {
    if (savedIds.has(idea.id)) {
      removeIdea(idea.id);
      setSavedIds((prev) => {
        const next = new Set(prev);
        next.delete(idea.id);
        return next;
      });
    } else {
      saveIdea(idea);
      setSavedIds((prev) => new Set(prev).add(idea.id));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-5">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          className="w-16 h-16 rounded-full gradient-hero mb-4 flex items-center justify-center"
        >
          <SlidersHorizontal size={24} className="text-primary-foreground" />
        </motion.div>
        <p className="font-display font-semibold text-foreground">Generating Ideas...</p>
        <p className="text-sm text-muted-foreground mt-1">Analyzing your budget and location</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24">
      <div className="px-5 pt-6 max-w-md mx-auto">
        <div className="flex items-center gap-3 mb-5">
          <Button variant="ghost" size="icon" onClick={() => navigate("/explore")}>
            <ArrowLeft size={20} />
          </Button>
          <div>
            <h1 className="text-lg font-display font-bold text-foreground">Business Ideas</h1>
            <p className="text-xs text-muted-foreground">
              {ideas.length} ideas for ₹{input?.budget.toLocaleString("en-IN")} in {input?.location}
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {ideas.map((idea, i) => (
            <IdeaCard
              key={idea.id}
              idea={idea}
              index={i}
              onSelect={(idea) => navigate(`/idea/${idea.id}`, { state: idea })}
              onSave={handleSave}
              isSaved={savedIds.has(idea.id)}
            />
          ))}
        </div>

        {ideas.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No ideas match your criteria. Try adjusting your budget.</p>
            <Button variant="outline" className="mt-4" onClick={() => navigate("/explore")}>
              Adjust Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
