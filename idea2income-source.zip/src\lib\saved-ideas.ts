import { BusinessIdea } from "./types";

const STORAGE_KEY = "idea2income_saved";

export function getSavedIdeas(): BusinessIdea[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveIdea(idea: BusinessIdea): void {
  const saved = getSavedIdeas();
  if (!saved.find((s) => s.id === idea.id)) {
    saved.push(idea);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
  }
}

export function removeIdea(id: string): void {
  const saved = getSavedIdeas().filter((s) => s.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
}

export function isIdeaSaved(id: string): boolean {
  return getSavedIdeas().some((s) => s.id === id);
}
