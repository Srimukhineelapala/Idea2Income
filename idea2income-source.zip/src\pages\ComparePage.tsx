import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { BarChart3, Plus, X, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { BusinessIdea } from "@/lib/types";
import { getSavedIdeas } from "@/lib/saved-ideas";
import { CategoryIcon } from "@/components/CategoryIcon";
import { Button } from "@/components/ui/button";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

export default function ComparePage() {
  const navigate = useNavigate();
  const [saved, setSaved] = useState<BusinessIdea[]>([]);
  const [selected, setSelected] = useState<BusinessIdea[]>([]);
  const [showPicker, setShowPicker] = useState(false);

  useEffect(() => {
    setSaved(getSavedIdeas());
  }, []);

  const addIdea = (idea: BusinessIdea) => {
    if (selected.length < 3 && !selected.find((s) => s.id === idea.id)) {
      setSelected([...selected, idea]);
    }
    setShowPicker(false);
  };

  const removeFromCompare = (id: string) => {
    setSelected(selected.filter((s) => s.id !== id));
  };

  const chartData = selected.map((idea) => ({
    name: idea.name.length > 12 ? idea.name.slice(0, 12) + "…" : idea.name,
    Investment: idea.investment.total,
    Profit: idea.profit,
    Expenses: idea.monthlyExpense.total,
  }));

  return (
    <div className="min-h-screen pb-24">
      <div className="px-5 pt-8 max-w-md mx-auto">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-2 mb-1">
            <BarChart3 size={20} className="text-primary" />
            <h1 className="text-xl font-display font-bold text-foreground">Compare Ideas</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-6">Select up to 3 saved ideas to compare</p>
        </motion.div>

        {/* Selected Ideas */}
        <div className="flex gap-2 mb-6">
          {selected.map((idea) => (
            <motion.div
              key={idea.id}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex-1 bg-card border border-border rounded-lg p-3 shadow-card relative"
            >
              <button onClick={() => removeFromCompare(idea.id)} className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-destructive rounded-full flex items-center justify-center">
                <X size={12} className="text-destructive-foreground" />
              </button>
              <CategoryIcon category={idea.category} size={16} />
              <p className="text-xs font-medium text-foreground mt-1 truncate">{idea.name}</p>
            </motion.div>
          ))}
          {selected.length < 3 && (
            <button
              onClick={() => setShowPicker(true)}
              className="flex-1 border-2 border-dashed border-border rounded-lg p-3 flex flex-col items-center justify-center text-muted-foreground hover:border-primary/30 transition-colors"
            >
              <Plus size={16} />
              <span className="text-xs mt-1">Add</span>
            </button>
          )}
        </div>

        {/* Picker */}
        {showPicker && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-card border border-border rounded-lg p-4 shadow-card mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-foreground">Pick a saved idea</h3>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShowPicker(false)}>
                <X size={14} />
              </Button>
            </div>
            {saved.filter((s) => !selected.find((sel) => sel.id === s.id)).length === 0 ? (
              <p className="text-xs text-muted-foreground">No more saved ideas. Save some from Explore!</p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {saved
                  .filter((s) => !selected.find((sel) => sel.id === s.id))
                  .map((idea) => (
                    <button
                      key={idea.id}
                      onClick={() => addIdea(idea)}
                      className="w-full flex items-center gap-2 p-2.5 rounded-md hover:bg-muted/50 transition-colors text-left"
                    >
                      <CategoryIcon category={idea.category} size={16} />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{idea.name}</p>
                        <p className="text-xs text-muted-foreground">₹{idea.investment.total.toLocaleString("en-IN")}</p>
                      </div>
                    </button>
                  ))}
              </div>
            )}
          </motion.div>
        )}

        {/* Comparison Chart */}
        {selected.length >= 2 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            <div className="bg-card border border-border rounded-lg p-5 shadow-card">
              <h2 className="font-display font-semibold text-foreground mb-3">Financial Comparison</h2>
              <div className="h-52">
                <ResponsiveContainer>
                  <BarChart data={chartData}>
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}K`} />
                    <Tooltip formatter={(v: number) => `₹${v.toLocaleString("en-IN")}`} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Bar dataKey="Investment" fill="hsl(152, 55%, 38%)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Profit" fill="hsl(80, 50%, 45%)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Expenses" fill="hsl(168, 40%, 48%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Detail Table */}
            <div className="bg-card border border-border rounded-lg shadow-card overflow-hidden">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-muted/50">
                    <th className="text-left p-3 font-medium text-muted-foreground">Metric</th>
                    {selected.map((s) => (
                      <th key={s.id} className="text-right p-3 font-medium text-foreground">{s.name.length > 10 ? s.name.slice(0, 10) + "…" : s.name}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    { label: "Investment", fn: (i: BusinessIdea) => `₹${i.investment.total.toLocaleString("en-IN")}` },
                    { label: "Monthly Income", fn: (i: BusinessIdea) => `₹${i.monthlyIncome.toLocaleString("en-IN")}` },
                    { label: "Monthly Profit", fn: (i: BusinessIdea) => `₹${i.profit.toLocaleString("en-IN")}` },
                    { label: "Profit %", fn: (i: BusinessIdea) => `${i.profitPercentage}%` },
                    { label: "Break Even", fn: (i: BusinessIdea) => `${i.breakEvenMonths} mo` },
                    { label: "Risk", fn: (i: BusinessIdea) => i.riskLevel },
                    { label: "Growth", fn: (i: BusinessIdea) => `${i.growthPotential}/10` },
                  ].map((row) => (
                    <tr key={row.label} className="border-t border-border">
                      <td className="p-3 text-muted-foreground">{row.label}</td>
                      {selected.map((s) => (
                        <td key={s.id} className="p-3 text-right font-medium text-foreground">{row.fn(s)}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {selected.length < 2 && (
          <div className="text-center py-12">
            <BarChart3 size={48} className="mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground text-sm">
              {saved.length === 0
                ? "Save some ideas first to compare them!"
                : "Select at least 2 ideas to start comparing"}
            </p>
            {saved.length === 0 && (
              <Button variant="hero" className="mt-4" onClick={() => navigate("/explore")}>
                Explore Ideas
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
