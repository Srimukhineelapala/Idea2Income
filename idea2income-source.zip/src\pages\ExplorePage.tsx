import { useState } from "react";
import { motion } from "framer-motion";
import { Search, MapPin, Utensils, Globe, ShoppingBag, Wrench, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { BusinessInput, Category, SkillLevel } from "@/lib/types";

const categories: { id: Category; label: string; icon: React.ElementType }[] = [
  { id: "food", label: "Food", icon: Utensils },
  { id: "online", label: "Online", icon: Globe },
  { id: "retail", label: "Retail", icon: ShoppingBag },
  { id: "services", label: "Services", icon: Wrench },
];

const skillLevels: { id: SkillLevel; label: string }[] = [
  { id: "beginner", label: "Beginner" },
  { id: "intermediate", label: "Intermediate" },
  { id: "expert", label: "Expert" },
];

const popularCities = ["Vijayawada", "Hyderabad", "Bangalore", "Chennai", "Mumbai", "Delhi", "Pune"];

export default function ExplorePage() {
  const navigate = useNavigate();
  const [budget, setBudget] = useState(50000);
  const [category, setCategory] = useState<Category>("food");
  const [skillLevel, setSkillLevel] = useState<SkillLevel>("beginner");
  const [location, setLocation] = useState("Vijayawada");

  const handleGenerate = () => {
    const input: BusinessInput = { budget, category, skillLevel, location };
    navigate("/results", { state: input });
  };

  return (
    <div className="min-h-screen pb-24">
      <div className="px-5 pt-8 max-w-md mx-auto">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <div className="flex items-center gap-2 mb-1">
            <Search size={20} className="text-primary" />
            <h1 className="text-xl font-display font-bold text-foreground">Explore Ideas</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-6">Tell us about your plans</p>
        </motion.div>

        {/* Budget */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">
            Budget: <span className="text-primary font-display font-bold">₹{budget.toLocaleString("en-IN")}</span>
          </label>
          <Slider
            value={[budget]}
            onValueChange={([v]) => setBudget(v)}
            min={10000}
            max={500000}
            step={5000}
            className="mt-2"
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>₹10,000</span>
            <span>₹5,00,000</span>
          </div>
        </motion.div>

        {/* Category */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">Category</label>
          <div className="grid grid-cols-4 gap-2">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setCategory(c.id)}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border transition-all ${
                  category === c.id
                    ? "border-primary bg-primary/5 text-primary"
                    : "border-border bg-card text-muted-foreground hover:border-primary/30"
                }`}
              >
                <c.icon size={20} />
                <span className="text-xs font-medium">{c.label}</span>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Skill Level */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">Skill Level</label>
          <div className="grid grid-cols-3 gap-2">
            {skillLevels.map((s) => (
              <button
                key={s.id}
                onClick={() => setSkillLevel(s.id)}
                className={`py-2.5 px-3 rounded-lg border text-sm font-medium transition-all ${
                  skillLevel === s.id
                    ? "border-primary bg-primary/5 text-primary"
                    : "border-border bg-card text-muted-foreground hover:border-primary/30"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Location */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">
            <MapPin size={14} className="inline mr-1" />
            Location
          </label>
          <Input
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Enter your city"
            className="mb-2"
          />
          <div className="flex flex-wrap gap-1.5">
            {popularCities.map((city) => (
              <button
                key={city}
                onClick={() => setLocation(city)}
                className={`px-2.5 py-1 rounded-full text-xs font-medium border transition-all ${
                  location === city
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:border-primary/30"
                }`}
              >
                {city}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Generate */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Button variant="hero" size="lg" className="w-full" onClick={handleGenerate}>
            <Sparkles size={18} />
            Generate Business Ideas
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
